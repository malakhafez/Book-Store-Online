package proxy;

import model.Book;
import model.BookComponent;
import singleton.SessionManager;
import java.util.HashMap;
import java.util.Map;

public class BookProxy implements BookComponent {
    private Book realBook;

    // Cache مشترك لكل الكتب (Lazy Loading)
    private static final Map<Integer, String> contentCache = new HashMap<>();

    public BookProxy(Book book) {
        this.realBook = book;
    }

    // ===== Access Control (مثل UML) =====
    private boolean checkAccess() {
        var user = SessionManager.getInstance().getCurrentUser();
        if (user == null) return false;

        String role = user.getRole();
        return role.equals("Admin") || role.equals("Librarian") || role.equals("Member");
    }

    @Override
    public String getTitle() {
        return realBook.getTitle();
    }

    @Override
    public String getAuthor() {
        return realBook.getAuthor();
    }

    // Lazy Loading + Caching
    @Override
    public String read() {
        // 1. Access Control
        if (!checkAccess()) {
            return "You must login first";
        }

        int bookId = realBook.getBookId();

        // 2. Check Cache (هل الكتاب اتقرأ قبل كده؟)
        if (contentCache.containsKey(bookId)) {
            System.out.println("[Cache] Loading from cache: " + realBook.getTitle());
            return contentCache.get(bookId);  // ← سريع، من غير تأخير
        }

        // 3. First time reading (Lazy Loading)
        System.out.println("[Lazy Loading] Loading book for first time: " + realBook.getTitle());

        // محاكاة وقت التحميل (زي تحميل PDF)
        try {
            Thread.sleep(3000);  // ينام 3 ثواني عشان يحاكي التحميل
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // تحميل المحتوى (أول مرة)
        String content = realBook.read();

        // حفظ في cache
        contentCache.put(bookId, content);
        System.out.println("[Cache] Book saved to cache: " + realBook.getTitle());

        return content;
    }

    // ===== Operations that need management rights =====
    public boolean canManage() {
        return checkAccess() &&
                (SessionManager.getInstance().isAdmin() ||
                        SessionManager.getInstance().isLibrarian());
    }

    public String readBook() {
        if (SessionManager.getInstance().getCurrentUser() == null) {
            return "❌ لازم تسجل دخول أولاً";
        }
        // استخدام نفس الـ read() اللي فيها Lazy Loading
        return read();
    }

    public String getBookInfo() {
        String role = SessionManager.getInstance().getCurrentUserRole();
        if (role.equals("Guest")) {
            return realBook.getTitle() + " (سجل دخول للقراءة)";
        }
        return realBook.getTitle() + " - " + realBook.getAuthor() +
                " [" + realBook.getCategory() + "]";
    }


}