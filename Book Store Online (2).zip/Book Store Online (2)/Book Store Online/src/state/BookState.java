package state;

import model.Book;
import java.io.Serializable;

public interface BookState extends Serializable {
    String borrow(Book book);
    String reserve(Book book);
    String returnBook(Book book);
    String getStateName();
}