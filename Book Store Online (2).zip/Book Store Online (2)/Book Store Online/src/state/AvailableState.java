package state;

import model.Book;
import java.io.Serializable;

public class AvailableState implements BookState, Serializable {

    @Override
    public String borrow(Book book) {
        book.setState(new BorrowedState());
        return "Book '" + book.getTitle() + "' has been borrowed successfully";
    }

    @Override
    public String reserve(Book book) {
        book.setState(new ReservedState());
        return "Book '" + book.getTitle() + "' has been reserved successfully";
    }

    @Override
    public String returnBook(Book book) {
        return "Book '" + book.getTitle() + "' is not borrowed";
    }

    @Override
    public String getStateName() {
        return "Available";
    }
}