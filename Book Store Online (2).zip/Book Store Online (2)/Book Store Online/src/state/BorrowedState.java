package state;

import model.Book;
import java.io.Serializable;

public class BorrowedState implements BookState, Serializable {

    @Override
    public String borrow(Book book) {
        return "Book '" + book.getTitle() + "' is currently borrowed, cannot be borrowed";
    }

    @Override
    public String reserve(Book book) {
        book.setState(new ReservedState());
        return "Book '" + book.getTitle() + "' has been reserved, you will be notified when returned";
    }

    @Override
    public String returnBook(Book book) {
        book.setState(new AvailableState());
        return "Book '" + book.getTitle() + "' has been returned, thank you";
    }

    @Override
    public String getStateName() {
        return "Borrowed";
    }
}