package state;

import model.Book;
import java.io.Serializable;

public class ReservedState implements BookState, Serializable {

    @Override
    public String borrow(Book book) {
        return "Book is reserved for someone else, cannot be borrowed";
    }

    @Override
    public String reserve(Book book) {
        return "Book is already reserved for someone else";
    }

    @Override
    public String returnBook(Book book) {
        book.setState(new AvailableState());
        return "Book returned successfully, the person who reserved it will be notified";
    }

    @Override
    public String getStateName() {
        return "Reserved";
    }
}