package factory;

import model.User;
import model.Member;
import model.Librarian;
import model.Admin;
import java.io.Serializable;

public class UserFactory extends UserCreator implements Serializable {

    @Override
    public User createUser(String type, String fullName, String email, String password) {
        switch (type.toLowerCase()) {
            case "admin":
                return new Admin(fullName, email, password);
            case "librarian":
                return new Librarian(fullName, email, password);
            case "member":
                return new Member(fullName, email, password);
            default:
                return new Member(fullName, email, password);
        }
    }

}
