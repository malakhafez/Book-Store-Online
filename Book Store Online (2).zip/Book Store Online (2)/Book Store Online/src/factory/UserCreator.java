package factory;

import model.User;
import java.io.Serializable;

public abstract class UserCreator implements Serializable {
    public abstract User createUser(String type, String fullName, String email, String password);
}