package factory;

import model.*;
import java.io.Serializable;

public class BookFactory extends BookCreator implements Serializable {
    private static final long serialVersionUID = 1L;

    @Override
    public Book createBook(String title, String author) {
        // Default book type
        return new NovelBook(title, author);
    }

    // Factory Methods حسب النوع
    public Book createNovel(String title, String author) {
        return new NovelBook(title, author);
    }

    public Book createHistoryBook(String title, String author) {
        return new HistoryBook(title, author);
    }

    public Book createScienceBook(String title, String author) {
        return new ScienceBook(title, author);
    }

    // Factory Method حسب Category (String)
    public Book createBook(String title, String author, String category) {
        switch (category.toLowerCase()) {
            case "رواية":
            case "novel":
                return createNovel(title, author);
            case "تاريخ":
            case "history":
                return createHistoryBook(title, author);
            case "علوم":
            case "science":
                return createScienceBook(title, author);
            default:
                return createNovel(title, author); // Default
        }
    }
}