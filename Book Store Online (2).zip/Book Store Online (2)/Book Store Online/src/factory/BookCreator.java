package factory;

import model.Book;
import java.io.Serializable;

public abstract class BookCreator implements Serializable {
    private static final long serialVersionUID = 1L;

    // Factory Method - هيتم تنفيذه في الكلاسات الفرعية
    public abstract Book createBook(String title, String author);

    // Template Method (اختياري - لإضافة سلوك مشترك)
    public Book createBookWithCategory(String title, String author, String category) {
        Book book = createBook(title, author);
        // يمكن إضافة سلوك إضافي هنا في المستقبل
        return book;
    }
}