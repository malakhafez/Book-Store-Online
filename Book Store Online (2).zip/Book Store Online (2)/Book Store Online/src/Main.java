import facade.LibraryFacade;
import proxy.BookProxy;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        LibraryFacade library = new LibraryFacade();

        System.out.println("========== 1. تسجيل Member جديد ==========");
        System.out.println(library.signUp("Ahmed Ali", "ahmed@test.com", "123", "123"));

        System.out.println("\n========== 2. تسجيل دخول Member ==========");
        System.out.println(library.login("ahmed@test.com", "123"));

        System.out.println("\n========== 3. Member يحاول يضيف كتاب (ممنوع) ==========");
        System.out.println(library.addBook("كتاب جديد", "مؤلف مجهول"));

        System.out.println("\n========== 4. Member يشوف الكتب ==========");
        ArrayList<BookProxy> books = library.getAllBooksWithProxy();
        for (BookProxy bp : books) {
            System.out.println(bp.getBookInfo());
        }

        System.out.println("\n========== 5. Member يقرأ كتاب ==========");
        System.out.println(library.readBook(1));

        System.out.println("\n========== 6. Member يقرأ نفس الكتاب تاني (من Cache) ==========");
        System.out.println(library.readBook(1));

        System.out.println("\n========== 7. تسجيل خروج ==========");
        library.logout();

        System.out.println("\n========== 8. تسجيل دخول Admin ==========");
        System.out.println(library.login("admin@library.com", "admin123"));

        System.out.println("\n========== 9. Admin يضيف كتاب جديد ==========");
        System.out.println(library.addBook("الكتاب العظيم", "كاتب كبير"));

        System.out.println("\n========== 10. كل الكتب بعد الإضافة ==========");
        books = library.getAllBooksWithProxy();
        for (int i = 0; i < books.size(); i++) {
            System.out.println((i+1) + ". " + books.get(i).getBookInfo());
        }

        System.out.println("\n========== 11. Admin يقرأ كتاب ==========");
        System.out.println(library.readBook(3));

        System.out.println("\n========== 12. عرض جميع المستخدمين (للـ Admin بس) ==========");
        var users = library.getAllUsers();
        for (var u : users) {
            System.out.println(u.getUserId() + " - " + u.getFullName() + " (" + u.getRole() + ")");
        }
        System.out.println("\n========== تجربة Decorator ==========");
        System.out.println(library.testDecorator(1));
        System.out.println("\n========== تجربة State Pattern ==========");

// كتاب ID = 1
        System.out.println("حالة الكتاب: " + library.getBookState(1));

// استعارة الكتاب
        System.out.println(library.borrowBook(1));
        System.out.println("حالة الكتاب بعد الاستعارة: " + library.getBookState(1));

// محاولة استعارة تاني
        System.out.println(library.borrowBook(1));

// حجز الكتاب
        System.out.println(library.reserveBook(1));

// إرجاع الكتاب
        System.out.println(library.returnBook(1));
        System.out.println("حالة الكتاب بعد الإرجاع: " + library.getBookState(1));
        System.out.println("\n========== تجربة Strategy Pattern ==========");

// معرف المستخدم (Ahmed Ali ID = 2)
        int userId = 2;

// عرض طرق الإعارة
        System.out.println(library.showBorrowStrategies());

// استعارة كتاب بطريقة أسبوعية
        System.out.println("\n--- استعارة الكتاب رقم 1 (أسبوعي) ---");
        System.out.println(library.borrowBookWithStrategy(1, 2, userId));

// عرض استعارات المستخدم
        System.out.println("\n--- استعاراتي الحالية ---");
        System.out.println(library.getUserBorrows(userId));

// إرجاع الكتاب
        System.out.println("\n--- إرجاع الكتاب ---");
        System.out.println(library.returnBookWithId(1, userId));

// عرض استعارات المستخدم بعد الإرجاع
        System.out.println("\n--- استعاراتي بعد الإرجاع ---");
        System.out.println(library.getUserBorrows(userId));
        System.out.println("\n========== تجربة إدارة الكتب ==========");

// عرض كل الكتب
        System.out.println(library.getAllBooksWithState());

// البحث عن كتاب
        System.out.println(library.searchBookByTitle("الأمير"));

// إضافة كتاب (كـ Admin)
        System.out.println(library.addBook("الكتاب الجديد", "مؤلف جديد"));

// تعديل كتاب
        System.out.println(library.updateBook(3, "الكتاب المعدل", "مؤلف معدل"));

// تفاصيل كتاب
        System.out.println(library.getBookDetails(3));

// حذف كتاب
        System.out.println(library.deleteBook(4));  // الكتاب اللي ضفناه

        System.out.println("\n========== تجربة إدارة المستخدمين (Admin فقط) ==========");

// عرض كل المستخدمين
        System.out.println(library.getAllUsersFormatted());

// البحث عن مستخدم
        System.out.println(library.searchUserByName("Ahmed"));

// تفاصيل مستخدم
        System.out.println(library.getUserDetails(2));

// تعديل مستخدم
        System.out.println(library.updateUser(2, "أحمد علي الجديد", null));

// عرض المستخدمين بعد التعديل
        System.out.println(library.getAllUsersFormatted());
    }
}