package javafx;

import javafx.application.Application;
import javafx.animation.PauseTransition;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class SplashScreen extends Application {

    private Stage splashStage;
    private Stage loginStage;

    @Override
    public void start(Stage primaryStage) {
        this.splashStage = primaryStage;

        // إعدادات الشاشة (بلا إطار)
        splashStage.initStyle(StageStyle.UNDECORATED);

        // المحتوى
        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #2c3e50; -fx-padding: 30;");

        // اللوجو
        ImageView logo = null;
        try {
            Image logoImage = new Image(getClass().getResourceAsStream("Imeges/OIP.webp"));            logo = new ImageView(logoImage);
            logo.setFitHeight(100);
            logo.setFitWidth(100);
            logo.setPreserveRatio(true);
        } catch (Exception e) {
            System.out.println("⚠️ Logo not found");
        }

        // اسم البرنامج
        Text appName = new Text("📚 Online Library System");
        appName.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-fill: white;");

        // مؤشر تحميل
        ProgressIndicator loadingIndicator = new ProgressIndicator();
        loadingIndicator.setStyle("-fx-progress-color: #3498db;");

        // نص تحميل
        Text loadingText = new Text("Loading...");
        loadingText.setStyle("-fx-fill: #bdc3c7; -fx-font-size: 14px;");

        // ProgressBar (اختياري)
        ProgressBar progressBar = new ProgressBar();
        progressBar.setPrefWidth(300);
        progressBar.setStyle("-fx-accent: #27ae60;");

        if (logo != null) root.getChildren().add(logo);
        root.getChildren().addAll(appName, loadingIndicator, loadingText);

        Scene scene = new Scene(root, 500, 400);
        splashStage.setScene(scene);
        splashStage.show();

        // محاكاة التحميل (تأخير 3 ثواني)
        PauseTransition delay = new PauseTransition(Duration.seconds(3));
        delay.setOnFinished(event -> {
            splashStage.close();
            showLoginScreen();
        });
        delay.play();

        // تحديث الـ progress bar تدريجياً (اختياري)
        new Thread(() -> {
            double progress = 0;
            while (progress < 1) {
                progress += 0.1;
                final double p = progress;
                javafx.application.Platform.runLater(() -> {
                    progressBar.setProgress(p);
                });
                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void showLoginScreen() {
        loginStage = new Stage();
        LoginScreen loginScreen = new LoginScreen();
        try {
            loginScreen.start(loginStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}