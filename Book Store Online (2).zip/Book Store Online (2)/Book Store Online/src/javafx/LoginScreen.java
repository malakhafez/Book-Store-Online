package javafx;

import facade.LibraryFacade;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LoginScreen extends Application {

    private LibraryFacade library;
    private Stage primaryStage;

    // TabPane
    private TabPane tabPane;

    // Login fields
    private TextField loginEmailField;
    private PasswordField loginPasswordField;
    private Label loginMessageLabel;

    // SignUp fields
    private TextField signupNameField;
    private TextField signupEmailField;
    private PasswordField signupPasswordField;
    private PasswordField signupConfirmField;
    private Label signupMessageLabel;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.library = new LibraryFacade();

        // Main layout
        BorderPane mainLayout = new BorderPane();
        mainLayout.setStyle("-fx-background-color: #f0f4f8;");

        // Title
        Label titleLabel = new Label("📚 Online Library System");
        titleLabel.getStyleClass().add("title-label");
        titleLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        BorderPane.setAlignment(titleLabel, Pos.CENTER);
        BorderPane.setMargin(titleLabel, new Insets(20));
        mainLayout.setTop(titleLabel);

        // TabPane
        tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.setStyle("-fx-background-color: white;");

        createLoginTab();
        createSignupTab();

        tabPane.getTabs().addAll(loginTab, signupTab);
        mainLayout.setCenter(tabPane);
        BorderPane.setMargin(tabPane, new Insets(20));

        Scene scene = new Scene(mainLayout, 500, 550);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        primaryStage.setTitle("Online Library System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void createLoginTab() {
        Tab loginTab = new Tab("Login");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(30));

        Label emailLabel = new Label("Email:");
        loginEmailField = new TextField();
        loginEmailField.setPromptText("example@email.com");
        loginEmailField.setPrefWidth(250);

        Label passwordLabel = new Label("Password:");
        loginPasswordField = new PasswordField();
        loginPasswordField.setPromptText("********");
        loginPasswordField.setPrefWidth(250);

        Button loginButton = new Button("🔐 Login");
        loginButton.getStyleClass().add("button");


        loginButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        loginMessageLabel = new Label();
        loginMessageLabel.getStyleClass().add("error-label");
        loginMessageLabel.setStyle("-fx-text-fill: red;");

//        Button demoButton = new Button("Demo Login (Admin)");
//        demoButton.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 12px;");

        grid.add(emailLabel, 0, 0);
        grid.add(loginEmailField, 1, 0);
        grid.add(passwordLabel, 0, 1);
        grid.add(loginPasswordField, 1, 1);
        grid.add(loginButton, 1, 2);
        grid.add(loginMessageLabel, 1, 3);
//        grid.add(demoButton, 1, 4);

        loginButton.setOnAction(e -> handleLogin());
//        demoButton.setOnAction(e -> fillDemoData());

        loginTab.setContent(grid);
        this.loginTab = loginTab;
    }

    private void createSignupTab() {
        Tab signupTab = new Tab("Sign Up");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(30));

        Label nameLabel = new Label("Full Name:");
        signupNameField = new TextField();
        signupNameField.setPromptText("Ahmed Mohamed");
        signupNameField.setPrefWidth(250);

        Label emailLabel = new Label("Email:");
        signupEmailField = new TextField();
        signupEmailField.setPromptText("example@email.com");
        signupEmailField.setPrefWidth(250);

        Label passwordLabel = new Label("Password:");
        signupPasswordField = new PasswordField();
        signupPasswordField.setPromptText("********");
        signupPasswordField.setPrefWidth(250);

        Label confirmLabel = new Label("Confirm Password:");
        signupConfirmField = new PasswordField();
        signupConfirmField.setPromptText("********");
        signupConfirmField.setPrefWidth(250);


        Button signupButton = new Button("📝 Sign Up");
        signupButton.getStyleClass().add("button-success");
        signupButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        signupMessageLabel = new Label();
        signupMessageLabel.getStyleClass().add("error-label");
        signupMessageLabel.setStyle("-fx-text-fill: red;");

        grid.add(nameLabel, 0, 0);
        grid.add(signupNameField, 1, 0);
        grid.add(emailLabel, 0, 1);
        grid.add(signupEmailField, 1, 1);
        grid.add(passwordLabel, 0, 2);
        grid.add(signupPasswordField, 1, 2);
        grid.add(confirmLabel, 0, 3);
        grid.add(signupConfirmField, 1, 3);
        grid.add(signupButton, 1, 4);
        grid.add(signupMessageLabel, 1, 5);

        signupButton.setOnAction(e -> handleSignup());

        signupTab.setContent(grid);
        this.signupTab = signupTab;
    }

    private void handleLogin() {
        String email = loginEmailField.getText();
        String password = loginPasswordField.getText();

        System.out.println("DEBUG: Trying to login with email: " + email);

        String result = library.login(email, password);
        System.out.println("DEBUG: Login result: " + result);

        if (result.startsWith("success:")) {
            String role = result.split(":")[1];
            System.out.println("DEBUG: Role: " + role);
            openDashboard(role);
        } else {
            loginMessageLabel.setText(result);
        }
    }

    private void handleSignup() {
        String name = signupNameField.getText();
        String email = signupEmailField.getText();
        String password = signupPasswordField.getText();
        String confirm = signupConfirmField.getText();

        // Password strength validation before calling library
        String passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        if (!password.matches(passwordRegex)) {
            signupMessageLabel.setStyle("-fx-text-fill: red;");
            signupMessageLabel.setText("Weak password! Use 8+ chars with uppercase, lowercase, number, and special char (@$!%*?&)");
            return;
        }

        String result = library.signUp(name, email, password, confirm);
        signupMessageLabel.setText(result);

        if (result.equals("Account created successfully")) {
            // Clear fields
            signupNameField.clear();
            signupEmailField.clear();
            signupPasswordField.clear();
            signupConfirmField.clear();
            tabPane.getSelectionModel().select(0);
            loginMessageLabel.setStyle("-fx-text-fill: green;");
            loginMessageLabel.setText("Account created! Please login");
        }
    }
    private void fillDemoData() {
        loginEmailField.setText("admin@library.com");
        loginPasswordField.setText("admin123");
        loginMessageLabel.setStyle("-fx-text-fill: green;");
        loginMessageLabel.setText("👤 Admin demo: admin@library.com / admin123");
    }

    private void openDashboard(String role) {
        try {
            Stage dashboardStage = new Stage();

            switch (role) {
                case "Admin":
                    AdminDashboard adminDashboard = new AdminDashboard(library);
                    adminDashboard.start(dashboardStage);
                    break;
                case "Librarian":
                    LibrarianDashboard librarianDashboard = new LibrarianDashboard(library);
                    librarianDashboard.start(dashboardStage);
                    break;
                default:
                    MemberDashboard memberDashboard = new MemberDashboard(library);
                    memberDashboard.start(dashboardStage);
}

            primaryStage.close();

        } catch (Exception e) {
        e.printStackTrace();
        }
                }


    // Temporary dashboard until we create the real ones
    private void showTempDashboard(String title, String role) {
        Stage stage = new Stage();
        BorderPane layout = new BorderPane();
        layout.setStyle("-fx-background-color: #ecf0f1;");

        Button logoutButton = new Button("🚪 Logout");
        logoutButton.getStyleClass().add("button-danger");

        Label welcomeLabel = new Label("👋 Welcome, " + library.getCurrentUserName() + "!\nRole: " + role);
        welcomeLabel.setStyle("-fx-font-size: 20px; -fx-text-fill: #2c3e50;");
        welcomeLabel.setAlignment(Pos.CENTER);
        logoutButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        logoutButton.setOnAction(e -> {
            library.logout();
            stage.close();

            // Reopen login screen
            Stage loginStage = new Stage();
            LoginScreen loginScreen = new LoginScreen();
            try {
                loginScreen.start(loginStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox centerBox = new VBox(20, welcomeLabel, logoutButton);
        centerBox.setAlignment(Pos.CENTER);
        layout.setCenter(centerBox);

        Scene scene = new Scene(layout, 600, 400);
        stage.setTitle(title);
        stage.setScene(scene);
        stage.show();
    }
    @Override
    public void stop() {
        if (library != null) {
            library.saveData();
            System.out.println("✅ Data saved from LoginScreen");
        }
    }
    private Tab loginTab;
    private Tab signupTab;
}