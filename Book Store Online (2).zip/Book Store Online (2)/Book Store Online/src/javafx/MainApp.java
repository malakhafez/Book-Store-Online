package javafx;

import javafx.application.Application;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        // بدلاً من فتح LoginScreen مباشرة، نفتح SplashScreen
        SplashScreen splashScreen = new SplashScreen();
        splashScreen.start(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }

}