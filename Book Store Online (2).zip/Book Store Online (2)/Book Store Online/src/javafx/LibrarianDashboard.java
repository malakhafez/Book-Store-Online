package javafx;

import facade.LibraryFacade;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LibrarianDashboard extends Application {

    private LibraryFacade library;
    private Stage primaryStage;

    // Common Areas
    private TextArea displayArea;
    private TextArea resultArea;
    private Label messageLabel;

    // Book Management Fields
    private TextField addTitleField, addAuthorField;
    private TextField updateIdField, updateTitleField, updateAuthorField;
    private TextField deleteIdField;
    private TextField searchField;
    private ComboBox<String> searchTypeCombo;

    public LibrarianDashboard(LibraryFacade library) {
        this.library = library;
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        BorderPane mainLayout = new BorderPane();
        mainLayout.setStyle("-fx-background-color: #f0f4f8;");

        // Top Bar
        VBox topBox = createTopBar();
        mainLayout.setTop(topBox);

        // Center Tabs
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.getTabs().addAll(
                createBrowseTab(),
                createAddBookTab(),
                createUpdateBookTab(),
                createDeleteBookTab(),
                createSearchTab()
        );

        mainLayout.setCenter(tabPane);

        Scene scene = new Scene(mainLayout, 950, 650);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        primaryStage.setTitle("Librarian Dashboard - " + library.getCurrentUserName());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createTopBar() {
        VBox topBox = new VBox(10);
        topBox.setPadding(new Insets(15));
        topBox.setStyle("-fx-background-color: #2c3e50;");

        Label welcomeLabel = new Label("👋 Welcome, " + library.getCurrentUserName());
        welcomeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;");

        Label roleLabel = new Label("📌 Role: " + library.getCurrentUserRole() + " (Can Manage Books)");
        roleLabel.setStyle("-fx-text-fill: #f39c12; -fx-font-size: 14px;");

        Button logoutButton = new Button("🚪 Logout");
        logoutButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 5 15;");
        logoutButton.setOnAction(e -> handleLogout());

        HBox topContent = new HBox(20, welcomeLabel, roleLabel, logoutButton);
        topContent.setAlignment(Pos.CENTER_LEFT);

        topBox.getChildren().add(topContent);
        return topBox;
    }

    private Tab createBrowseTab() {
        Tab tab = new Tab("📚 Browse Books");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        displayArea = new TextArea();
        displayArea.setEditable(false);
        displayArea.setPrefHeight(450);
        displayArea.setStyle("-fx-font-size: 14px;");

        Button refreshButton = new Button("🔄 Refresh");
        refreshButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");
        refreshButton.setOnAction(e -> showAllBooks());

        content.getChildren().addAll(refreshButton, displayArea);
        tab.setContent(content);

        tab.setOnSelectionChanged(e -> {
            if (tab.isSelected()) showAllBooks();
        });

        return tab;
    }

    private Tab createAddBookTab() {
        Tab tab = new Tab("➕ Add Book");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(30));

        Label titleLabel = new Label("Title:");
        addTitleField = new TextField();
        addTitleField.setPrefWidth(300);
        addTitleField.setPromptText("Book title");

        Label authorLabel = new Label("Author:");
        addAuthorField = new TextField();
        addAuthorField.setPrefWidth(300);
        addAuthorField.setPromptText("Author name");

        Button addButton = new Button("Add Book");
        addButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: green;");

        resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setPrefHeight(150);

        addButton.setOnAction(e -> {
            String title = addTitleField.getText();
            String author = addAuthorField.getText();

            if (title.isEmpty() || author.isEmpty()) {
                messageLabel.setStyle("-fx-text-fill: red;");
                messageLabel.setText("❌ Please fill all fields");
                return;
            }

            String result = library.addBook(title, author);
            resultArea.setText(result);
            messageLabel.setText("");
            addTitleField.clear();
            addAuthorField.clear();
            showAllBooks();
        });

        grid.add(titleLabel, 0, 0);
        grid.add(addTitleField, 1, 0);
        grid.add(authorLabel, 0, 1);
        grid.add(addAuthorField, 1, 1);
        grid.add(addButton, 1, 2);
        grid.add(messageLabel, 1, 3);

        VBox content = new VBox(20, grid, resultArea);
        content.setPadding(new Insets(20));
        tab.setContent(content);

        return tab;
    }

    private Tab createUpdateBookTab() {
        Tab tab = new Tab("✏️ Update Book");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(30));

        Label idLabel = new Label("Book ID:");
        updateIdField = new TextField();
        updateIdField.setPromptText("Enter book ID");
        updateIdField.setPrefWidth(200);

        Label titleLabel = new Label("New Title:");
        updateTitleField = new TextField();
        updateTitleField.setPromptText("New title");
        updateTitleField.setPrefWidth(300);

        Label authorLabel = new Label("New Author:");
        updateAuthorField = new TextField();
        updateAuthorField.setPromptText("New author");
        updateAuthorField.setPrefWidth(300);

        Button updateButton = new Button("Update Book");
        updateButton.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        Label updateMessage = new Label();

        resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setPrefHeight(150);

        updateButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(updateIdField.getText());
                String title = updateTitleField.getText();
                String author = updateAuthorField.getText();

                String result = library.updateBook(id, title, author);
                resultArea.setText(result);
                updateIdField.clear();
                updateTitleField.clear();
                updateAuthorField.clear();
                showAllBooks();
            } catch (NumberFormatException ex) {
                resultArea.setText("❌ Invalid Book ID");
            }
        });

        grid.add(idLabel, 0, 0);
        grid.add(updateIdField, 1, 0);
        grid.add(titleLabel, 0, 1);
        grid.add(updateTitleField, 1, 1);
        grid.add(authorLabel, 0, 2);
        grid.add(updateAuthorField, 1, 2);
        grid.add(updateButton, 1, 3);
        grid.add(updateMessage, 1, 4);

        VBox content = new VBox(20, grid, resultArea);
        content.setPadding(new Insets(20));
        tab.setContent(content);

        return tab;
    }

    private Tab createDeleteBookTab() {
        Tab tab = new Tab("🗑️ Delete Book");

        VBox content = new VBox(15);
        content.setPadding(new Insets(30));
        content.setAlignment(Pos.TOP_CENTER);

        Label instructionLabel = new Label("Enter Book ID to delete:");
        instructionLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        deleteIdField = new TextField();
        deleteIdField.setPromptText("Book ID");
        deleteIdField.setPrefWidth(200);

        Button deleteButton = new Button("Delete Book");
        deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setPrefHeight(200);

        deleteButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(deleteIdField.getText());
                String result = library.deleteBook(id);
                resultArea.setText(result);
                deleteIdField.clear();
                showAllBooks();
            } catch (NumberFormatException ex) {
                resultArea.setText("❌ Invalid Book ID");
            }
        });

        content.getChildren().addAll(instructionLabel, deleteIdField, deleteButton, resultArea);
        tab.setContent(content);

        return tab;
    }

    private Tab createSearchTab() {
        Tab tab = new Tab("🔍 Search Books");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER);

        searchTypeCombo = new ComboBox<>();
        searchTypeCombo.getItems().addAll("By Title", "By Author");
        searchTypeCombo.setValue("By Title");

        searchField = new TextField();
        searchField.setPromptText("Enter search keyword...");
        searchField.setPrefWidth(300);

        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");

        TextArea searchResultArea = new TextArea();
        searchResultArea.setEditable(false);
        searchResultArea.setPrefHeight(350);

        searchButton.setOnAction(e -> {
            String keyword = searchField.getText();
            if (keyword.isEmpty()) {
                searchResultArea.setText("❌ Please enter a search keyword");
                return;
            }

            String result;
            if (searchTypeCombo.getValue().equals("By Title")) {
                result = library.searchBookByTitle(keyword);
            } else {
                result = library.searchBookByAuthor(keyword);
            }
            searchResultArea.setText(result);
        });

        searchBox.getChildren().addAll(searchTypeCombo, searchField, searchButton);
        content.getChildren().addAll(searchBox, searchResultArea);
        tab.setContent(content);

        return tab;
    }

    private void showAllBooks() {
        String books = library.getAllBooksWithState();
        if (displayArea != null) {
            displayArea.setText(books);
        }
    }

    private void handleLogout() {
        library.logout();
        primaryStage.close();

        Stage loginStage = new Stage();
        LoginScreen loginScreen = new LoginScreen();
        try {
            loginScreen.start(loginStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void stop() {
        if (library != null) {
            library.saveData();
            System.out.println("✅ Data saved from Dashboard");
        }
    }
}