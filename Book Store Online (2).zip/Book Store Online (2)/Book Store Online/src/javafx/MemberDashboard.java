package javafx;

import decorator.AudioBook;
import decorator.PDFBook;
import decorator.SummarizedBook;
import facade.LibraryFacade;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.BookComponent;
import model.Member;

public class MemberDashboard extends Application {

    private LibraryFacade library;
    private Stage primaryStage;

    // UI Components
    private TextArea displayArea;
    private TextField searchField;
    private ComboBox<String> searchTypeCombo;
    private TextField bookIdField;
    private ComboBox<String> borrowStrategyCombo;

    public MemberDashboard(LibraryFacade library) {
        this.library = library;
    }
    @Override
    public void stop() {
        if (library != null) {
            library.saveData();
            System.out.println("✅ Data saved from Dashboard");
        }
    }
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.library = new LibraryFacade();

        BorderPane mainLayout = new BorderPane();
        mainLayout.setStyle("-fx-background-color: #f0f4f8;");
        System.out.println("DEBUG: Dashboard current user: " + library.getCurrentUserName());

        // Top: Welcome + Logout
        VBox topBox = createTopBar();
        mainLayout.setTop(topBox);

        // Center: Tabs
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        tabPane.getTabs().addAll(
                createBrowseTab(),
                createBorrowTab(),
                createMyBooksTab(),
                createDecorateTab(),
                createSearchTab()
        );

        mainLayout.setCenter(tabPane);

        Scene scene = new Scene(mainLayout, 900, 650);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        primaryStage.setTitle("Member Dashboard - " + library.getCurrentUserName());
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    private VBox createTopBar() {
        VBox topBox = new VBox(10);
        topBox.setPadding(new Insets(15));
        topBox.setStyle("-fx-background-color: #2c3e50;");

        Label welcomeLabel = new Label("Welcome, " + library.getCurrentUserName() + " 👋");
        welcomeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;");

        Label roleLabel = new Label("Role: " + library.getCurrentUserRole());
        roleLabel.setStyle("-fx-text-fill: #bdc3c7; -fx-font-size: 14px;");

        Button logoutButton = new Button("Logout");
        logoutButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 5 15;");
        logoutButton.setOnAction(e -> handleLogout());

        HBox topContent = new HBox(20, welcomeLabel, roleLabel, logoutButton);
        topContent.setAlignment(Pos.CENTER_LEFT);

        topBox.getChildren().add(topContent);
        return topBox;
    }

    private Tab createBrowseTab() {
        Tab tab = new Tab("Browse Books");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        displayArea = new TextArea();
        displayArea.setEditable(false);
        displayArea.setPrefHeight(350);
        displayArea.setStyle("-fx-font-size: 14px;");

        Button refreshButton = new Button("Refresh");
        refreshButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");
        refreshButton.setOnAction(e -> showAllBooks());

        content.getChildren().addAll(displayArea, refreshButton);
        tab.setContent(content);

        tab.setOnSelectionChanged(e -> {
            if (tab.isSelected()) showAllBooks();
        });

        return tab;
    }
    private Tab createDecorateTab() {
        Tab tab = new Tab("✨ Decorate Book");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        // Book selection
        Label bookLabel = new Label("Enter Book ID:");
        TextField bookIdField = new TextField();
        bookIdField.setPromptText("e.g., 1");
        bookIdField.setPrefWidth(200);

        // Feature selection
        Label featuresLabel = new Label("Select features:");
        CheckBox pdfCheckBox = new CheckBox("📄 PDF Version");
        CheckBox audioCheckBox = new CheckBox("🎧 Audio Version");
        CheckBox summaryCheckBox = new CheckBox("📝 Summary");

        VBox featuresBox = new VBox(10, pdfCheckBox, audioCheckBox, summaryCheckBox);
        featuresBox.setAlignment(Pos.CENTER_LEFT);

        // Decorate button
        Button decorateButton = new Button("Apply Decorators");
        decorateButton.setStyle("-fx-background-color: #9b59b6; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        // Result area
        TextArea resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setPrefHeight(300);
        resultArea.setStyle("-fx-font-size: 14px;");

        decorateButton.setOnAction(e -> {
            try {
                int bookId = Integer.parseInt(bookIdField.getText());

                // Get the book as BookComponent
                BookComponent book = library.getBookComponentById(bookId);                if (book == null) {
                    resultArea.setText("Book not found!");
                    return;
                }

                // Apply decorators based on checkboxes
                BookComponent decorated = book;
                StringBuilder applied = new StringBuilder();

                if (pdfCheckBox.isSelected()) {
                    decorated = new PDFBook(decorated);
                    applied.append("📄 PDF, ");
                }
                if (audioCheckBox.isSelected()) {
                    decorated = new AudioBook(decorated);
                    applied.append("🎧 Audio, ");
                }
                if (summaryCheckBox.isSelected()) {
                    decorated = new SummarizedBook(decorated);
                    applied.append("📝 Summary, ");
                }

                if (applied.length() == 0) {
                    resultArea.setText("No features selected!\n\n" + book.read());
                    return;
                }

                // Show result
                String result = "📚 Book: " + book.getTitle() + "\n";
                result += "✨ Applied: " + applied.substring(0, applied.length() - 2) + "\n";
                result += "\n--- Reading ---\n";
                result += decorated.read();

                resultArea.setText(result);

            } catch (NumberFormatException ex) {
                resultArea.setText("Please enter a valid Book ID");
            } catch (Exception ex) {
                resultArea.setText("Error: " + ex.getMessage());
            }
        });

        content.getChildren().addAll(
                bookLabel, bookIdField,
                featuresLabel, featuresBox,
                decorateButton, resultArea
        );

        tab.setContent(content);
        return tab;
    }
    private Tab createBorrowTab() {
        Tab tab = new Tab("Borrow Book");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        Label instructionLabel = new Label("Enter Book ID to borrow:");
        instructionLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        bookIdField = new TextField();
        bookIdField.setPromptText("e.g., 1");
        bookIdField.setPrefWidth(200);

        Label strategyLabel = new Label("Choose borrowing strategy:");
        borrowStrategyCombo = new ComboBox<>();
        borrowStrategyCombo.getItems().addAll(
                "1 - Daily (1 day - 5 EGP)",
                "2 - Weekly (7 days - 20 EGP)",
                "3 - Monthly (30 days - 50 EGP)"
        );
        borrowStrategyCombo.setValue("2 - Weekly (7 days - 20 EGP)");
        borrowStrategyCombo.setPrefWidth(300);
        // داخل createBorrowTab() - بعد تعريف borrowStrategyCombo


        Button borrowButton = new Button("Borrow Book");
        borrowButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: blue;");

        TextArea resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setPrefHeight(200);

        borrowButton.setOnAction(e -> {
            try {
                int bookId = Integer.parseInt(bookIdField.getText());
                int strategyChoice = Integer.parseInt(borrowStrategyCombo.getValue().substring(0, 1));
                int userId = getCurrentUserId();

                String result = library.borrowBookWithStrategy(bookId, strategyChoice, userId);
                resultArea.setText(result);
                messageLabel.setText("");
                showAllBooks(); // Refresh book list
            } catch (NumberFormatException ex) {
                messageLabel.setText("❌ Please enter a valid Book ID");
            }
        });

        content.getChildren().addAll(instructionLabel, bookIdField, strategyLabel, borrowStrategyCombo, borrowButton, messageLabel, resultArea);
        tab.setContent(content);

        return tab;
    }


    private Tab createMyBooksTab() {
        Tab tab = new Tab("My Books");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        TextArea myBooksArea = new TextArea();
        myBooksArea.setEditable(false);
        myBooksArea.setPrefHeight(300);

        // حقل إدخال رقم الكتاب عشان يقرأه
        Label readLabel = new Label("Enter Book ID to read:");
        TextField readBookField = new TextField();
        readBookField.setPromptText("Book ID");
        readBookField.setPrefWidth(150);

        Button readButton = new Button("Read Book");
        readButton.setStyle("-fx-background-color: #9b59b6; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        TextArea readResultArea = new TextArea();
        readResultArea.setEditable(false);
        readResultArea.setPrefHeight(150);
        readResultArea.setStyle("-fx-font-size: 14px;");

        // حقل إرجاع الكتاب
        TextField returnBookField = new TextField();
        returnBookField.setPromptText("Book ID to return");
        returnBookField.setPrefWidth(150);

        Button returnButton = new Button("Return Book");
        returnButton.setStyle("-fx-background-color: #e67e22; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        Label returnMessage = new Label();

        Button refreshButton = new Button("Refresh");
        refreshButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white;");

        readButton.setOnAction(e -> {
            try {
                int bookId = Integer.parseInt(readBookField.getText());
                String result = library.readBook(bookId);
                readResultArea.setText(result);
            } catch (NumberFormatException ex) {
                readResultArea.setText("Please enter a valid Book ID");
            }
        });

        returnButton.setOnAction(e -> {
            try {
                int bookId = Integer.parseInt(returnBookField.getText());
                int userId = getCurrentUserId();
                String result = library.returnBookWithId(bookId, userId);
                returnMessage.setText(result);
                refreshMyBooks(myBooksArea);
                readBookField.clear();
                returnBookField.clear();
            } catch (NumberFormatException ex) {
                returnMessage.setText("Please enter a valid Book ID");
            }
        });

        refreshButton.setOnAction(e -> refreshMyBooks(myBooksArea));

        HBox readBox = new HBox(10, readLabel, readBookField, readButton);
        readBox.setAlignment(Pos.CENTER);

        HBox returnBox = new HBox(10, new Label("Return Book:"), returnBookField, returnButton, refreshButton);
        returnBox.setAlignment(Pos.CENTER);

        content.getChildren().addAll(
                new Label("Books Currently Have:"),
                myBooksArea,
                readBox,
                readResultArea,
                returnBox,
                returnMessage
        );

        tab.setContent(content);

        tab.setOnSelectionChanged(e -> {
            if (tab.isSelected()) refreshMyBooks(myBooksArea);
        });

        return tab;
    }
    private Tab createSearchTab() {
        Tab tab = new Tab("Search Books");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER);

        searchTypeCombo = new ComboBox<>();
        searchTypeCombo.getItems().addAll("By Title", "By Author");
        searchTypeCombo.setValue("By Title");

        searchField = new TextField();
        searchField.setPromptText("Enter search keyword...");
        searchField.setPrefWidth(300);

        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");

        TextArea searchResultArea = new TextArea();
        searchResultArea.setEditable(false);
        searchResultArea.setPrefHeight(350);

        searchButton.setOnAction(e -> {
            String keyword = searchField.getText();
            if (keyword.isEmpty()) {
                searchResultArea.setText("❌ Please enter a search keyword");
                return;
            }

            String result;
            if (searchTypeCombo.getValue().equals("By Title")) {
                result = library.searchBookByTitle(keyword);
            } else {
                result = library.searchBookByAuthor(keyword);
            }
            searchResultArea.setText(result);
        });

        searchBox.getChildren().addAll(searchTypeCombo, searchField, searchButton);
        content.getChildren().addAll(searchBox, searchResultArea);
        tab.setContent(content);

        return tab;
    }

    private void showAllBooks() {
        String books = library.getAllBooksWithState();
        displayArea.setText(books);
    }

    private void readBook(int bookId) {
        String result = library.readBook(bookId);  // دي بتستخدم الـ Proxy
        displayArea.setText(result);
    }
    private void refreshMyBooks(TextArea area) {
        int userId = getCurrentUserId();
        String borrows = library.getUserBorrows(userId);
        area.setText(borrows);
    }

    private int getCurrentUserId() {
        return library.getCurrentUserId();
    }

    private void handleLogout() {
        library.logout();
        primaryStage.close();

        // Reopen login screen
        Stage loginStage = new Stage();
        LoginScreen loginScreen = new LoginScreen();
        try {
            loginScreen.start(loginStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}