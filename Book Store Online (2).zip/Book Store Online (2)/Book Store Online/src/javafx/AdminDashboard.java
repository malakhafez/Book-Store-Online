package javafx;

import facade.LibraryFacade;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.User;

public class AdminDashboard extends Application {

    private LibraryFacade library;
    private Stage primaryStage;

    // Common Areas
    private TextArea displayArea;
    private TextArea resultArea;

    // Book Management Fields
    private TextField addTitleField, addAuthorField;
    private ComboBox<String> addCategoryCombo;
    private TextField updateIdField, updateTitleField, updateAuthorField;
    private TextField deleteIdField;
    private TextField searchField;
    private ComboBox<String> searchTypeCombo;

    // User Management Fields
    private TextField addUserNameField, addUserEmailField, addUserPasswordField;
    private ComboBox<String> addUserRoleCombo;
    private TextField deleteUserIdField;
    private TextField updateUserIdField, updateUserNameField, updateUserPassField;
    private TextField searchUserField;
    private ComboBox<String> searchUserTypeCombo;

    public AdminDashboard(LibraryFacade library) {
        this.library = library;
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        BorderPane mainLayout = new BorderPane();
        mainLayout.setStyle("-fx-background-color: #f0f4f8;");

        // Top Bar
        VBox topBox = createTopBar();
        mainLayout.setTop(topBox);

        // Center Tabs
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.getTabs().addAll(
                createBrowseBooksTab(),
                createAddBookTab(),        // ← إضافة كتاب
                createUpdateBookTab(),     // ← تعديل كتاب
                createDeleteBookTab(),     // ← حذف كتاب
                createSearchBookTab(),     // ← بحث في الكتب
                createManageUsersTab(),
                createAddUserTab(),
                createUpdateUserTab(),
                createDeleteUserTab(),
                createBorrowedBooksTab(),
                createSearchUserTab()
        );

        mainLayout.setCenter(tabPane);

        Scene scene = new Scene(mainLayout, 1100, 750);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        primaryStage.setTitle("Admin Dashboard - " + library.getCurrentUserName());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createTopBar() {
        VBox topBox = new VBox(10);
        topBox.setPadding(new Insets(15));
        topBox.setStyle("-fx-background-color: #2c3e50;");

        Label welcomeLabel = new Label("👋 Welcome, " + library.getCurrentUserName());
        welcomeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;");

        Label roleLabel = new Label("📌 Role: " + library.getCurrentUserRole() + " (Full Access)");
        roleLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-size: 14px; -fx-font-weight: bold;");

        Button logoutButton = new Button("🚪 Logout");
        logoutButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 5 15;");
        logoutButton.setOnAction(e -> handleLogout());

        HBox topContent = new HBox(20, welcomeLabel, roleLabel, logoutButton);
        topContent.setAlignment(Pos.CENTER_LEFT);

        topBox.getChildren().add(topContent);
        return topBox;
    }

    // ==================== Book Management Tabs ====================
    private Tab createBorrowedBooksTab() {
        Tab tab = new Tab("📖 Borrowed Books");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        TextArea borrowedBooksArea = new TextArea();
        borrowedBooksArea.setEditable(false);
        borrowedBooksArea.setPrefHeight(500);
        borrowedBooksArea.setStyle("-fx-font-size: 14px;");

        Button refreshButton = new Button("🔄 Refresh");
        refreshButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");
        refreshButton.setOnAction(e -> {
            String data = library.getAllBorrowedBooksWithDetails();
            borrowedBooksArea.setText(data);
        });

        content.getChildren().addAll(refreshButton, borrowedBooksArea);
        tab.setContent(content);

        tab.setOnSelectionChanged(e -> {
            if (tab.isSelected()) {
                String data = library.getAllBorrowedBooksWithDetails();
                borrowedBooksArea.setText(data);
            }
        });

        return tab;
    }
    private Tab createBrowseBooksTab() {
        Tab tab = new Tab("📚 Browse Books");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        displayArea = new TextArea();
        displayArea.setEditable(false);
        displayArea.setPrefHeight(500);
        displayArea.setStyle("-fx-font-size: 14px;");

        Button refreshButton = new Button("🔄 Refresh");
        refreshButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");
        refreshButton.setOnAction(e -> showAllBooks());

        content.getChildren().addAll(refreshButton, displayArea);
        tab.setContent(content);

        tab.setOnSelectionChanged(e -> {
            if (tab.isSelected()) showAllBooks();
        });

        return tab;
    }

    private Tab createAddBookTab() {
        Tab tab = new Tab("➕ Add Book");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(30));

        Label titleLabel = new Label("Title:");
        addTitleField = new TextField();
        addTitleField.setPrefWidth(300);
        addTitleField.setPromptText("Book title");

        Label authorLabel = new Label("Author:");
        addAuthorField = new TextField();
        addAuthorField.setPrefWidth(300);
        addAuthorField.setPromptText("Author name");

        Label categoryLabel = new Label("Category:");
        addCategoryCombo = new ComboBox<>();
        addCategoryCombo.getItems().addAll("Novel", "Historical", "Science");
        addCategoryCombo.setValue("Novel");
        addCategoryCombo.setPrefWidth(200);

        Button addButton = new Button("Add Book");
        addButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size:14px; -fx-padding: 8 20;");

        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: green;");

        TextArea addResultArea = new TextArea();
        addResultArea.setEditable(false);
        addResultArea.setPrefHeight(100);

        addButton.setOnAction(e -> {
            String title = addTitleField.getText();
            String author = addAuthorField.getText();
            String category = addCategoryCombo.getValue();

            if (title.isEmpty() || author.isEmpty()) {
                messageLabel.setStyle("-fx-text-fill: red;");
                messageLabel.setText("❌ All fields required");
                return;
            }

            String result = library.addBook(title, author, category);
            addResultArea.setText(result);
            messageLabel.setText("");
            addTitleField.clear();
            addAuthorField.clear();
            showAllBooks();
        });

        grid.add(titleLabel, 0, 0);
        grid.add(addTitleField, 1, 0);
        grid.add(authorLabel, 0, 1);
        grid.add(addAuthorField, 1, 1);
        grid.add(categoryLabel, 0, 2);
        grid.add(addCategoryCombo, 1, 2);
        grid.add(addButton, 1, 3);

        VBox content = new VBox(20, grid, messageLabel, addResultArea);
        content.setPadding(new Insets(20));
        tab.setContent(content);

        return tab;
    }

    private Tab createUpdateBookTab() {
        Tab tab = new Tab("✏️ Update Book");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(30));

        Label idLabel = new Label("Book ID:");
        updateIdField = new TextField();
        updateIdField.setPromptText("Enter book ID");
        updateIdField.setPrefWidth(200);

        Label titleLabel = new Label("New Title:");
        updateTitleField = new TextField();
        updateTitleField.setPromptText("New title");
        updateTitleField.setPrefWidth(300);

        Label authorLabel = new Label("New Author:");
        updateAuthorField = new TextField();
        updateAuthorField.setPromptText("New author");
        updateAuthorField.setPrefWidth(300);

        Button updateButton = new Button("Update Book");
        updateButton.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        TextArea updateResultArea = new TextArea();
        updateResultArea.setEditable(false);
        updateResultArea.setPrefHeight(100);

        updateButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(updateIdField.getText());
                String title = updateTitleField.getText();
                String author = updateAuthorField.getText();

                String result = library.updateBook(id, title, author);
                updateResultArea.setText(result);
                updateIdField.clear();
                updateTitleField.clear();
                updateAuthorField.clear();
                showAllBooks();
            } catch (NumberFormatException ex) {
                updateResultArea.setText("❌ Invalid Book ID");
            }
        });

        grid.add(idLabel, 0, 0);
        grid.add(updateIdField, 1, 0);
        grid.add(titleLabel, 0, 1);
        grid.add(updateTitleField, 1, 1);
        grid.add(authorLabel, 0, 2);
        grid.add(updateAuthorField, 1, 2);
        grid.add(updateButton, 1, 3);

        VBox content = new VBox(20, grid, updateResultArea);
        content.setPadding(new Insets(20));
        tab.setContent(content);

        return tab;
    }

    private Tab createDeleteBookTab() {
        Tab tab = new Tab("🗑️ Delete Book");

        VBox content = new VBox(15);
        content.setPadding(new Insets(30));
        content.setAlignment(Pos.TOP_CENTER);

        Label instructionLabel = new Label("Enter Book ID to delete:");
        instructionLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        deleteIdField = new TextField();
        deleteIdField.setPromptText("Book ID");
        deleteIdField.setPrefWidth(200);

        Button deleteButton = new Button("Delete Book");
        deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        TextArea deleteResultArea = new TextArea();
        deleteResultArea.setEditable(false);
        deleteResultArea.setPrefHeight(150);

        deleteButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(deleteIdField.getText());
                String result = library.deleteBook(id);
                deleteResultArea.setText(result);
                deleteIdField.clear();
                showAllBooks();
            } catch (NumberFormatException ex) {
                deleteResultArea.setText("❌ Invalid Book ID");
            }
        });

        content.getChildren().addAll(instructionLabel, deleteIdField, deleteButton, deleteResultArea);
        tab.setContent(content);

        return tab;
    }

    private Tab createSearchBookTab() {
        Tab tab = new Tab("🔍 Search Books");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER);

        searchTypeCombo = new ComboBox<>();
        searchTypeCombo.getItems().addAll("By Title", "By Author");
        searchTypeCombo.setValue("By Title");

        searchField = new TextField();
        searchField.setPromptText("Enter search keyword...");
        searchField.setPrefWidth(300);

        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");

        TextArea searchResultArea = new TextArea();
        searchResultArea.setEditable(false);
        searchResultArea.setPrefHeight(350);

        searchButton.setOnAction(e -> {
            String keyword = searchField.getText();
            if (keyword.isEmpty()) {
                searchResultArea.setText("❌ Please enter a search keyword");
                return;
            }

            String result;
            if (searchTypeCombo.getValue().equals("By Title")) {
                result = library.searchBookByTitle(keyword);
            } else {
                result = library.searchBookByAuthor(keyword);
            }
            searchResultArea.setText(result);
        });

        searchBox.getChildren().addAll(searchTypeCombo, searchField, searchButton);
        content.getChildren().addAll(searchBox, searchResultArea);
        tab.setContent(content);

        return tab;
    }

    // ==================== User Management Tabs ====================

    private Tab createManageUsersTab() {
        Tab tab = new Tab("👥 View All Users");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setPrefHeight(500);
        resultArea.setStyle("-fx-font-size: 14px;");

        Button refreshButton = new Button("🔄 Refresh Users");
        refreshButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");
        refreshButton.setOnAction(e -> showAllUsers());

        content.getChildren().addAll(refreshButton, resultArea);
        tab.setContent(content);

        tab.setOnSelectionChanged(e -> {
            if (tab.isSelected()) showAllUsers();
        });

        return tab;
    }

    private Tab createAddUserTab() {
        Tab tab = new Tab("➕ Add User");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(30));

        Label nameLabel = new Label("Full Name:");
        addUserNameField = new TextField();
        addUserNameField.setPrefWidth(300);

        Label emailLabel = new Label("Email:");
        addUserEmailField = new TextField();
        addUserEmailField.setPrefWidth(300);

        Label passLabel = new Label("Password:");
        addUserPasswordField = new PasswordField();
        addUserPasswordField.setPrefWidth(300);

        Label roleLabel = new Label("Role:");
        addUserRoleCombo = new ComboBox<>();
        addUserRoleCombo.getItems().addAll("member", "librarian", "admin");
        addUserRoleCombo.setValue("member");

        Button addButton = new Button("Add User");
        addButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: red;");

        TextArea addResultArea = new TextArea();
        addResultArea.setEditable(false);
        addResultArea.setPrefHeight(100);

        addButton.setOnAction(e -> {
            String name = addUserNameField.getText();
            String email = addUserEmailField.getText();
            String pass = addUserPasswordField.getText();
            String role = addUserRoleCombo.getValue();

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                messageLabel.setStyle("-fx-text-fill: red;");
                messageLabel.setText("All fields required");
                return;
            }

            // Email validation
            String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
            if (!email.matches(emailRegex)) {
                messageLabel.setStyle("-fx-text-fill: red;");
                messageLabel.setText("Invalid email format");
                return;
            }

            String result = library.addUserByAdmin(name, email, pass, role);
            addResultArea.setText(result);

            if (result.startsWith("User added successfully")) {
                messageLabel.setStyle("-fx-text-fill: green;");
                messageLabel.setText("User added!");
                addUserNameField.clear();
                addUserEmailField.clear();
                addUserPasswordField.clear();
                showAllUsers();
            } else {
                messageLabel.setStyle("-fx-text-fill: red;");
                messageLabel.setText("Error adding user");
            }
        });

        grid.add(nameLabel, 0, 0);
        grid.add(addUserNameField, 1, 0);
        grid.add(emailLabel, 0, 1);
        grid.add(addUserEmailField, 1, 1);
        grid.add(passLabel, 0, 2);
        grid.add(addUserPasswordField, 1, 2);
        grid.add(roleLabel, 0, 3);
        grid.add(addUserRoleCombo, 1, 3);
        grid.add(addButton, 1, 4);

        VBox content = new VBox(20, grid, messageLabel, addResultArea);
        content.setPadding(new Insets(20));
        tab.setContent(content);

        return tab;
    }

    private Tab createUpdateUserTab() {
        Tab tab = new Tab("✏️ Update User");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(30));

        Label idLabel = new Label("User ID:");
        updateUserIdField = new TextField();
        updateUserIdField.setPromptText("Enter user ID");
        updateUserIdField.setPrefWidth(200);

        Label nameLabel = new Label("New Name:");
        updateUserNameField = new TextField();
        updateUserNameField.setPromptText("New name");
        updateUserNameField.setPrefWidth(300);

        Label passLabel = new Label("New Password:");
        updateUserPassField = new PasswordField();
        updateUserPassField.setPromptText("New password (optional)");
        updateUserPassField.setPrefWidth(300);

        Button updateButton = new Button("Update User");
        updateButton.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        TextArea updateResultArea = new TextArea();
        updateResultArea.setEditable(false);
        updateResultArea.setPrefHeight(100);

        updateButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(updateUserIdField.getText());
                String name = updateUserNameField.getText();
                String pass = updateUserPassField.getText();

                if (name.isEmpty()) {
                    updateResultArea.setText("❌ Name is required");
                    return;
                }

                String result = library.updateUser(id, name, pass.isEmpty() ? null : pass);
                updateResultArea.setText(result);

                if (result.startsWith("✅")) {
                    updateUserIdField.clear();
                    updateUserNameField.clear();
                    updateUserPassField.clear();
                    showAllUsers();
                }
            } catch (NumberFormatException ex) {
                updateResultArea.setText("❌ Invalid User ID");
            }
        });

        grid.add(idLabel, 0, 0);
        grid.add(updateUserIdField, 1, 0);
        grid.add(nameLabel, 0, 1);
        grid.add(updateUserNameField, 1, 1);
        grid.add(passLabel, 0, 2);
        grid.add(updateUserPassField, 1, 2);
        grid.add(updateButton, 1, 3);

        VBox content = new VBox(20, grid, updateResultArea);
        content.setPadding(new Insets(20));
        tab.setContent(content);

        return tab;
    }

    private Tab createDeleteUserTab() {
        Tab tab = new Tab("🗑️ Delete User");

        VBox content = new VBox(15);
        content.setPadding(new Insets(30));
        content.setAlignment(Pos.TOP_CENTER);

        Label instructionLabel = new Label("Enter User ID to delete:");
        instructionLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        deleteUserIdField = new TextField();
        deleteUserIdField.setPromptText("User ID");
        deleteUserIdField.setPrefWidth(200);

        Button deleteButton = new Button("Delete User");
        deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 8 20;");

        TextArea deleteResultArea = new TextArea();
        deleteResultArea.setEditable(false);
        deleteResultArea.setPrefHeight(150);

        deleteButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(deleteUserIdField.getText());
                String result = library.deleteUser(id);
                deleteResultArea.setText(result);
                deleteUserIdField.clear();
                showAllUsers();
            } catch (NumberFormatException ex) {
                deleteResultArea.setText("❌ Invalid User ID");
            }
        });

        content.getChildren().addAll(instructionLabel, deleteUserIdField, deleteButton, deleteResultArea);
        tab.setContent(content);

        return tab;
    }

    private Tab createSearchUserTab() {
        Tab tab = new Tab("🔍 Search User");

        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER);

        searchUserTypeCombo = new ComboBox<>();
        searchUserTypeCombo.getItems().addAll("By Name", "By Email");
        searchUserTypeCombo.setValue("By Name");

        searchUserField = new TextField();
        searchUserField.setPromptText("Enter search keyword...");
        searchUserField.setPrefWidth(300);

        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");

        TextArea searchResultArea = new TextArea();
        searchResultArea.setEditable(false);
        searchResultArea.setPrefHeight(350);

        searchButton.setOnAction(e -> {
            String keyword = searchUserField.getText();
            if (keyword.isEmpty()) {
                searchResultArea.setText("❌ Please enter a search keyword");
                return;
            }

            String result;
            if (searchUserTypeCombo.getValue().equals("By Name")) {
                result = library.searchUserByName(keyword);
            } else {
                result = library.searchUserByEmail(keyword);
            }
            searchResultArea.setText(result);
        });

        searchBox.getChildren().addAll(searchUserTypeCombo, searchUserField, searchButton);
        content.getChildren().addAll(searchBox, searchResultArea);
        tab.setContent(content);

        return tab;
    }

    // ==================== Helper Methods ====================

    private void showAllBooks() {
        String books = library.getAllBooksWithState();
        if (displayArea != null) {
            displayArea.setText(books);
        }
    }

    private void showAllUsers() {
        String users = library.getAllUsersFormatted();
        if (resultArea != null) {
            resultArea.setText(users);
        }
    }

    private void handleLogout() {
        library.logout();
        primaryStage.close();

        Stage loginStage = new Stage();
        LoginScreen loginScreen = new LoginScreen();
        try {
            loginScreen.start(loginStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void stop() {
        if (library != null) {
            library.saveData();
            System.out.println("✅ Data saved from AdminDashboard");
        }
    }
}