package decorator;

import model.BookComponent;

public abstract class BookDecorator implements BookComponent {
    protected BookComponent wrappee;  // الكائن اللي جواه

    public BookDecorator(BookComponent book) {
        this.wrappee = book;
    }

    @Override
    public String getTitle() {
        return wrappee.getTitle();
    }

    @Override
    public String getAuthor() {
        return wrappee.getAuthor();
    }

    @Override
    public String read() {
        return wrappee.read();
    }

    public abstract String getFeatures();
}