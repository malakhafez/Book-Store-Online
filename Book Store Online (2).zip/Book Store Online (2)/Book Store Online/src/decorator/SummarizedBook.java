package decorator;

import model.BookComponent;

public class SummarizedBook extends BookDecorator {

    public SummarizedBook(BookComponent book) {
        super(book);
    }

    @Override
    public String read() {
        return super.read() + "\n📝 (with book summary)";
    }

    @Override
    public String getFeatures() {
        return "📝 Book summary";
    }

    public String getSummary() {
        return "Summary of " + wrappee.getTitle() + ": This is a short summary...";
    }
}