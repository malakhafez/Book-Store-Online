package decorator;

import model.BookComponent;

public class AudioBook extends BookDecorator {

    public AudioBook(BookComponent book) {
        super(book);
    }

    @Override
    public String read() {
        return super.read() + "\n🎧 (with audio version)";
    }

    @Override
    public String getFeatures() {
        return "🎧 Audio version";
    }

    public String listenAudio() {
        return "Playing audiobook: " + wrappee.getTitle();
    }
}