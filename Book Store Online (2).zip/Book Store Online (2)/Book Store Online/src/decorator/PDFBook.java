package decorator;

import model.BookComponent;

public class PDFBook extends BookDecorator {

    public PDFBook(BookComponent book) {
        super(book);
    }

    @Override
    public String read() {
        return super.read() + "\n📄 (with downloadable PDF version)";
    }

    @Override
    public String getFeatures() {
        return "📄 PDF version";
    }

    public String downloadPDF() {
        return "Downloading PDF: " + wrappee.getTitle();
    }
}