package strategy;

import java.io.Serializable;

public class DailyBorrow implements BorrowStrategy, Serializable {
    private static final long serialVersionUID = 1L;

    @Override
    public int getDurationDays() { return 1; }

    @Override
    public double getPrice() { return 5.0; }

    @Override
    public double getFinePerDay() { return 2.0; }

    @Override
    public String getStrategyName() { return "Daily borrow (1 day - 5 EGP)"; }
}