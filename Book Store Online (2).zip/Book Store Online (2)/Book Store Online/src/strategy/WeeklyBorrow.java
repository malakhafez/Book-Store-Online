package strategy;

import java.io.Serializable;

public class WeeklyBorrow implements BorrowStrategy, Serializable {
    private static final long serialVersionUID = 1L;

    @Override
    public int getDurationDays() { return 7; }

    @Override
    public double getPrice() { return 20.0; }

    @Override
    public double getFinePerDay() { return 3.0; }

    @Override
    public String getStrategyName() { return "Weekly borrow (7 days - 20 EGP)"; }
}