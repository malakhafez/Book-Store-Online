package strategy;

import java.io.Serializable;

public interface BorrowStrategy extends Serializable {
    int getDurationDays();
    double getPrice();
    double getFinePerDay();
    String getStrategyName();
}