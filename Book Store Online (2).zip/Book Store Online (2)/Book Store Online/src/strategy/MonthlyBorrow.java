package strategy;

import java.io.Serializable;

public class MonthlyBorrow implements BorrowStrategy, Serializable {
    private static final long serialVersionUID = 1L;

    @Override
    public int getDurationDays() { return 30; }

    @Override
    public double getPrice() { return 50.0; }

    @Override
    public double getFinePerDay() { return 5.0; }

    @Override
    public String getStrategyName() { return "Monthly borrow (30 days - 50 EGP)"; }
}