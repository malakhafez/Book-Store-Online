package facade;

import java.io.*;
import java.util.ArrayList;

import factory.UserCreator;
import model.*;
import factory.UserFactory;
import factory.BookFactory;
import proxy.BookProxy;
import singleton.SessionManager;
import decorator.*;
import strategy.*;
import model.BorrowRecord;
import java.time.LocalDate;

public class LibraryFacade {

    private ArrayList<User> usersList;
    private ArrayList<Book> booksList;
    private ArrayList<BorrowRecord> borrowRecordsList;
    private static final String DATA_FILE = "library_data.ser";

    public LibraryFacade() {
        loadData();

        if (usersList == null) usersList = new ArrayList<>();
        if (booksList == null) booksList = new ArrayList<>();
        if (borrowRecordsList == null) borrowRecordsList = new ArrayList<>();

        if (usersList.isEmpty()) {
            addDefaultAdmin();
            addDefaultBooks();
        }
    }

    public void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            System.out.println("Saving data to file...");
            oos.writeObject(usersList);
            oos.writeObject(booksList);
            oos.writeObject(borrowRecordsList);
            System.out.println("Data saved successfully");
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadData() {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            System.out.println("No saved data found");
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            usersList = (ArrayList<User>) ois.readObject();
            booksList = (ArrayList<Book>) ois.readObject();
            borrowRecordsList = (ArrayList<BorrowRecord>) ois.readObject();
            fixCounters();
            System.out.println("Data loaded successfully");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }

    private void fixCounters() {
        int maxUserId = 0;
        int maxBookId = 0;
        int maxBorrowId = 0;

        for (User u : usersList) {
            if (u.getUserId() > maxUserId) maxUserId = u.getUserId();
        }
        for (Book b : booksList) {
            if (b.getBookId() > maxBookId) maxBookId = b.getBookId();
        }
        for (BorrowRecord br : borrowRecordsList) {
            if (br.getBorrowId() > maxBorrowId) maxBorrowId = br.getBorrowId();
        }

        User.setCounter(maxUserId + 1);
        Book.setCounter(maxBookId + 1);
        BorrowRecord.setCounter(maxBorrowId + 1);
    }

    private BookFactory bookFactory = new BookFactory();

    private void addDefaultBooks() {
        booksList.add(bookFactory.createNovel("The Little Prince", "Antoine"));
        booksList.add(bookFactory.createNovel("1984", "George Orwell"));
        booksList.add(bookFactory.createHistoryBook("Ancient Egyptian History", "Ahmed"));
        booksList.add(bookFactory.createScienceBook("Physics Basics", "Newton"));
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email != null && email.matches(emailRegex);
    }

    private boolean isStrongPassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean hasUpper = false;
        boolean hasLower = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else hasSpecial = true;
        }
        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    // ========== Sign Up ==========
    public String signUp(String fullName, String email, String password, String confirmPassword) {
        if (fullName.isEmpty() || email.isEmpty() || password.isEmpty()) {
            return "All fields are required";
        }
        if (!isValidEmail(email)) {
            return "Invalid email format. Example: name@domain.com";
        }
        if (!password.equals(confirmPassword)) {
            return "Passwords do not match";
        }
        if (!isStrongPassword(password)) {
            return "Weak password! Must be at least 8 characters, contain uppercase, lowercase, digit, and special character";
        }
        if (findUserByEmail(email) != null) {
            return "Email already registered";
        }
        UserCreator creator = new UserFactory();
        User newUser = creator.createUser("member", fullName, email, password);
        usersList.add(newUser);
        saveData();
        return "Account created successfully";
    }

    // ========== Login ==========
    public String login(String email, String password) {
        User user = findUserByEmail(email);
        if (user == null) {
            return "Email not registered";
        }
        if (!user.getPassword().equals(password)) {
            return "Incorrect password";
        }
        SessionManager.getInstance().login(user);
        return "success:" + user.getRole();
    }

    // ========== Logout ==========
    public void logout() {
        SessionManager.getInstance().logout();
    }

    // ========== Get Current User Info ==========
    public String getCurrentUserName() {
        return SessionManager.getInstance().getCurrentUserName();
    }

    public String getCurrentUserRole() {
        return SessionManager.getInstance().getCurrentUserRole();
    }

    public boolean isAdmin() {
        return SessionManager.getInstance().isAdmin();
    }

    public boolean isLibrarian() {
        return SessionManager.getInstance().isLibrarian();
    }

    public boolean isMember() {
        return SessionManager.getInstance().isMember();
    }

    public boolean isLoggedIn() {
        return SessionManager.getInstance().isLoggedIn();
    }

    // ========== Admin Only: Add User ==========
    public String addUserByAdmin(String fullName, String email, String password, String role) {
        if (!isAdmin()) {
            return "Access denied - Admin rights required";
        }
        if (!isValidEmail(email)) {
            return "Invalid email format. Example: name@domain.com";
        }
        if (!isStrongPassword(password)) {
            return "Weak password! Must be at least 8 characters, contain uppercase, lowercase, digit, and special character";
        }
        if (findUserByEmail(email) != null) {
            return "Email already exists";
        }
        UserCreator creator = new UserFactory();
        User newUser = creator.createUser(role, fullName, email, password);
        usersList.add(newUser);
        saveData();
        return "User added successfully: " + fullName + " (" + role + ")";
    }

    // ========== Admin Only: Get All Users ==========
    public ArrayList<User> getAllUsers() {
        if (!isAdmin()) {
            return new ArrayList<>();
        }
        return new ArrayList<>(usersList);
    }

    // ========== Admin Only: Delete User ==========
    public String deleteUser(int userId) {
        if (!isAdmin()) {
            return "Access denied - Admin rights required";
        }
        for (User u : usersList) {
            if (u.getUserId() == userId) {
                usersList.remove(u);
                saveData();
                return "User deleted successfully: " + u.getFullName();
            }
        }
        return "User not found";
    }

    // ========== Books Management ==========

    public ArrayList<BookProxy> getAllBooksWithProxy() {
        ArrayList<BookProxy> proxies = new ArrayList<>();
        for (Book b : booksList) {
            proxies.add(new BookProxy(b));
        }
        return proxies;
    }

    public String readBook(int bookId) {
        for (Book b : booksList) {
            if (b.getBookId() == bookId) {
                BookProxy proxy = new BookProxy(b);
                return proxy.readBook();  // ← بيستخدم Lazy Loading + Caching
            }
        }
        return "Book not found";
    }

    public String getAllBorrowedBooksWithDetails() {
        if (borrowRecordsList.isEmpty()) {
            return "No borrowing records found";
        }
        StringBuilder sb = new StringBuilder("Borrowed Books Report:\n");
        sb.append("========================================\n");
        for (BorrowRecord record : borrowRecordsList) {
            Book book = findBookById(record.getBookId());
            if (book == null) continue;
            User user = findUserById(record.getUserId());
            if (user == null) continue;
            String status = record.getReturnDate() == null ? "ACTIVE" : "RETURNED";
            sb.append("Book: ").append(book.getTitle())
                    .append(" | By: ").append(book.getAuthor()).append("\n");
            sb.append("  Borrower: ").append(user.getFullName())
                    .append(" (").append(user.getEmail()).append(")\n");
            sb.append("  Strategy: ").append(record.getStrategy().getStrategyName()).append("\n");
            sb.append("  Borrow Date: ").append(record.getBorrowDate())
                    .append(" | Due Date: ").append(record.getDueDate()).append("\n");
            sb.append("  Status: ").append(status);
            if (record.getReturnDate() != null) {
                sb.append(" | Returned: ").append(record.getReturnDate());
            }
            if (record.getFine() > 0) {
                sb.append(" | Fine: ").append(record.getFine()).append(" EGP");
            }
            sb.append("\n----------------------------------------\n");
        }
        return sb.toString();
    }

    public int getCurrentUserId() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        return currentUser != null ? currentUser.getUserId() : -1;
    }

    public String addBook(String title, String author, String category) {
        if (!new BookProxy(null).canManage()) {
            return "Access denied: insufficient permissions";
        }
        Book book = bookFactory.createBook(title, author, category);
        booksList.add(book);
        saveData();
        return "Book added successfully: " + title + " (" + category + ")";
    }

    public String addBook(String title, String author) {
        return addBook(title, author, "Novel");
    }

    // ========== Helper Methods ==========
    private User findUserByEmail(String email) {
        for (User u : usersList) {
            if (u.getEmail().equals(email)) {
                return u;
            }
        }
        return null;
    }

    public BookComponent getBookComponentById(int bookId) {
        for (Book b : booksList) {
            if (b.getBookId() == bookId) {
                return b;
            }
        }
        return null;
    }

    private void addDefaultAdmin() {
        if (findUserByEmail("admin@library.com") == null) {
            UserCreator creator = new UserFactory();
            User admin = creator.createUser("admin", "System Admin", "admin@library.com", "admin123");
            usersList.add(admin);
            System.out.println("Default Admin: admin@library.com / admin123");
        }
    }

    public String testDecorator(int bookId) {
        BookComponent book = getBookComponentById(bookId);
        if (book == null) {
            return "Book not found";
        }
        String result = "Original Book: " + book.getTitle() + "\n";
        BookComponent wrapped = book;
        wrapped = new PDFBook(wrapped);
        result += ((PDFBook) wrapped).getFeatures() + "\n";
        result += ((PDFBook) wrapped).downloadPDF() + "\n";
        wrapped = new AudioBook(wrapped);
        result += ((AudioBook) wrapped).getFeatures() + "\n";
        result += ((AudioBook) wrapped).listenAudio() + "\n";
        wrapped = new SummarizedBook(wrapped);
        result += ((SummarizedBook) wrapped).getFeatures() + "\n";
        result += ((SummarizedBook) wrapped).getSummary() + "\n";
        result += "\n--- Reading ---\n";
        result += wrapped.read();
        return result;
    }

    private Book findBookById(int bookId) {
        for (Book b : booksList) {
            if (b.getBookId() == bookId) {
                return b;
            }
        }
        return null;
    }

    public String borrowBook(int bookId) {
        Book book = findBookById(bookId);
        if (book == null) {
            return "Book not found";
        }
        return book.borrow();
    }

    public String reserveBook(int bookId) {
        Book book = findBookById(bookId);
        if (book == null) {
            return "Book not found";
        }
        return book.reserve();
    }

    public String returnBook(int bookId) {
        Book book = findBookById(bookId);
        if (book == null) {
            return "Book not found";
        }
        return book.returnBook();
    }

    public String getBookState(int bookId) {
        Book book = findBookById(bookId);
        if (book == null) {
            return "Book not found";
        }
        return book.getStateName();
    }

    // ========== Borrowing Methods ==========

    public String showBorrowStrategies() {
        return "Available borrowing strategies:\n" +
                "1. " + new DailyBorrow().getStrategyName() + "\n" +
                "2. " + new WeeklyBorrow().getStrategyName() + "\n" +
                "3. " + new MonthlyBorrow().getStrategyName();
    }

    public String borrowBookWithStrategy(int bookId, int strategyChoice, int userId) {
        Book book = findBookById(bookId);
        if (book == null) return "Book not found";

        if (!book.getStateName().equals("Available")) {
            return "Book not available - Status: " + book.getStateName();
        }

        User user = findUserById(userId);
        if (user == null) {
            return "User not found";
        }

        BorrowStrategy strategy;
        switch (strategyChoice) {
            case 1: strategy = new DailyBorrow(); break;
            case 2: strategy = new WeeklyBorrow(); break;
            case 3: strategy = new MonthlyBorrow(); break;
            default: return "Invalid strategy choice";
        }

        BorrowRecord record = new BorrowRecord(userId, bookId, strategy);
        borrowRecordsList.add(record);
        book.borrow();
        saveData();

        return "Book borrowed successfully!\n" +
                "Book: " + book.getTitle() + "\n" +
                "Due date: " + record.getDueDate() + "\n" +
                "Price: " + strategy.getPrice() + " EGP";
    }

    public String returnBookWithId(int bookId, int userId) {
        BorrowRecord activeRecord = null;
        for (BorrowRecord r : borrowRecordsList) {
            if (r.getBookId() == bookId && r.getUserId() == userId && r.getReturnDate() == null) {
                activeRecord = r;
                break;
            }
        }

        if (activeRecord == null) {
            return "No active borrow record found for this book";
        }

        activeRecord.setReturnDate(LocalDate.now());
        double fine = activeRecord.calculateFine();
        activeRecord.setFine(fine);
        Book book = findBookById(bookId);
        book.returnBook();
        saveData();

        String result = "Book returned successfully: " + book.getTitle() + "\n" +
                "Return date: " + activeRecord.getReturnDate() + "\n" +
                "Due date: " + activeRecord.getDueDate();

        if (fine > 0) {
            result += "\nLate fine: " + fine + " EGP";
        } else {
            result += "\nNo late fees";
        }
        return result;
    }

    public String getUserBorrows(int userId) {
        StringBuilder result = new StringBuilder("User borrows:\n");
        boolean hasBorrows = false;
        for (BorrowRecord r : borrowRecordsList) {
            if (r.getUserId() == userId && r.getReturnDate() == null) {
                Book book = findBookById(r.getBookId());
                result.append("• ").append(book.getTitle()).append(" | Due: ").append(r.getDueDate())
                        .append(" | ").append(r.getStrategy().getStrategyName()).append("\n");
                hasBorrows = true;
            }
        }
        if (!hasBorrows) {
            return "No active borrows";
        }
        return result.toString();
    }

    // ========== Book Management ==========

    public String searchBookByTitle(String title) {
        ArrayList<Book> results = new ArrayList<>();
        for (Book b : booksList) {
            if (b.getTitle().toLowerCase().contains(title.toLowerCase())) {
                results.add(b);
            }
        }
        if (results.isEmpty()) return "No books found with this title";
        StringBuilder sb = new StringBuilder("Search results by title:\n");
        for (Book b : results) {
            sb.append("• ").append(b.getBookId()).append(". ")
                    .append(b.getTitle()).append(" - ").append(b.getAuthor())
                    .append(" [").append(b.getStateName()).append("]\n");
        }
        return sb.toString();
    }

    public String searchBookByAuthor(String author) {
        ArrayList<Book> results = new ArrayList<>();
        for (Book b : booksList) {
            if (b.getAuthor().toLowerCase().contains(author.toLowerCase())) {
                results.add(b);
            }
        }
        if (results.isEmpty()) return "No books found by this author";
        StringBuilder sb = new StringBuilder("Books by this author:\n");
        for (Book b : results) {
            sb.append("• ").append(b.getBookId()).append(". ")
                    .append(b.getTitle()).append(" [").append(b.getStateName()).append("]\n");
        }
        return sb.toString();
    }

    public String updateBook(int bookId, String newTitle, String newAuthor) {
        BookProxy proxy = new BookProxy(null);
        if (!proxy.canManage()) {
            return "Access denied - insufficient permissions";
        }
        Book book = findBookById(bookId);
        if (book == null) return "Book not found";
        String oldTitle = book.getTitle();
        book.setTitle(newTitle);
        book.setAuthor(newAuthor);
        saveData();
        return "Book updated: " + oldTitle + " -> " + newTitle;
    }

    public String deleteBook(int bookId) {
        BookProxy proxy = new BookProxy(null);
        if (!proxy.canManage()) {
            return "Access denied - insufficient permissions";
        }
        Book book = findBookById(bookId);
        if (book == null) return "Book not found";
        if (book.getStateName().equals("Borrowed")) {
            return "Cannot delete a borrowed book";
        }
        String title = book.getTitle();
        booksList.remove(book);
        saveData();
        return "Book deleted: " + title;
    }

    public String getBookDetails(int bookId) {
        Book book = findBookById(bookId);
        if (book == null) return "Book not found";
        return "Title: " + book.getTitle() + "\n" +
                "Author: " + book.getAuthor() + "\n" +
                "Status: " + book.getStateName();
    }

    public String getAllBooksWithState() {
        if (booksList.isEmpty()) return "No books available";
        StringBuilder sb = new StringBuilder("Books list:\n");
        for (Book b : booksList) {
            sb.append("• ").append(b.getBookId()).append(". ")
                    .append(b.getTitle()).append(" [").append(b.getStateName()).append("]\n");
        }
        return sb.toString();
    }

    // ========== User Management ==========

    public String searchUserByName(String name) {
        if (!isAdmin()) return "Admin only feature";
        ArrayList<User> results = new ArrayList<>();
        for (User u : usersList) {
            if (u.getFullName().toLowerCase().contains(name.toLowerCase())) {
                results.add(u);
            }
        }
        if (results.isEmpty()) return "No results found";
        StringBuilder sb = new StringBuilder("Search results:\n");
        for (User u : results) {
            sb.append("• ID: ").append(u.getUserId()).append(" | ")
                    .append(u.getFullName()).append(" | ").append(u.getRole()).append("\n");
        }
        return sb.toString();
    }

    public String searchUserByEmail(String email) {
        if (!isAdmin()) return "Admin only feature";
        User user = findUserByEmail(email);
        if (user == null) return "User not found";
        return user.getFullName() + " | " + user.getRole();
    }

    public String updateUser(int userId, String newName, String newPassword) {
        if (!isAdmin()) return "Admin only feature";
        User user = findUserById(userId);
        if (user == null) return "User not found";
        String oldName = user.getFullName();
        user.setFullName(newName);
        if (newPassword != null && !newPassword.isEmpty()) {
            user.setPassword(newPassword);
        }
        saveData();
        return "User updated: " + oldName + " -> " + newName;
    }

    public String getUserDetails(int userId) {
        if (!isAdmin()) return "Admin only feature";
        User user = findUserById(userId);
        if (user == null) return "User not found";
        return "ID: " + user.getUserId() + "\n" +
                "Name: " + user.getFullName() + "\n" +
                "Email: " + user.getEmail() + "\n" +
                "Role: " + user.getRole();
    }

    public String getAllUsersFormatted() {
        if (!isAdmin()) return "Admin only feature";
        if (usersList.isEmpty()) return "No users found";
        StringBuilder sb = new StringBuilder("Users list:\n");
        for (User u : usersList) {
            sb.append("• ID: ").append(u.getUserId())
                    .append(" | ").append(u.getFullName())
                    .append(" | [").append(u.getRole()).append("]\n");
        }
        return sb.toString();
    }

    private User findUserById(int userId) {
        for (User u : usersList) {
            if (u.getUserId() == userId) return u;
        }
        return null;
    }
}