package singleton;

import model.User;

public class SessionManager {

    private static SessionManager instance;
    private User currentUser;

    private SessionManager() {}

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void login(User user) {
        this.currentUser = user;
        System.out.println("DEBUG: SessionManager.login() - User: " + user.getFullName());
    }

    public void logout() {
        this.currentUser = null;
        System.out.println("👋 تم تسجيل الخروج");
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public boolean isAdmin() {
        return currentUser != null && currentUser.getRole().equals("Admin");
    }

    public boolean isLibrarian() {
        return currentUser != null && currentUser.getRole().equals("Librarian");
    }

    public boolean isMember() {
        return currentUser != null && currentUser.getRole().equals("Member");
    }

    public String getCurrentUserRole() {
        return currentUser != null ? currentUser.getRole() : "Guest";
    }

    public String getCurrentUserName() {
        return currentUser != null ? currentUser.getFullName() : "Guest";
    }
}