package model;

import strategy.BorrowStrategy;
import java.time.LocalDate;
import java.io.Serializable;

public class BorrowRecord implements Serializable {
    private static final long serialVersionUID = 1L;
    private static int counter = 1;
    private int borrowId;
    private int userId;
    private int bookId;
    private BorrowStrategy strategy;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private double fine;

    public BorrowRecord(int userId, int bookId, BorrowStrategy strategy) {
        this.borrowId = counter++;
        this.userId = userId;
        this.bookId = bookId;
        this.strategy = strategy;
        this.borrowDate = LocalDate.now();
        this.dueDate = borrowDate.plusDays(strategy.getDurationDays());
        this.returnDate = null;
        this.fine = 0;
    }

    // Getters
    public int getBorrowId() { return borrowId; }
    public int getUserId() { return userId; }
    public int getBookId() { return bookId; }
    public BorrowStrategy getStrategy() { return strategy; }
    public LocalDate getBorrowDate() { return borrowDate; }
    public LocalDate getDueDate() { return dueDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public double getFine() { return fine; }

    // Setters
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }
    public void setFine(double fine) { this.fine = fine; }

    // للـ Local Storage
    public static void setCounter(int value) {
        counter = value;
    }

    public static int getCounter() {
        return counter;
    }

    // حساب الغرامة
    public double calculateFine() {
        if (returnDate == null) return 0;
        if (returnDate.isAfter(dueDate)) {
            long daysLate = java.time.temporal.ChronoUnit.DAYS.between(dueDate, returnDate);
            return daysLate * strategy.getFinePerDay();
        }
        return 0;
    }

    public String getStatus() {
        if (returnDate != null) return "مرتجع";
        if (LocalDate.now().isAfter(dueDate)) return "متأخر";
        return "نشط";
    }

    @Override
    public String toString() {
        return "📖 استعارة #" + borrowId + " | الكتاب ID: " + bookId +
                " | مستحق: " + dueDate + " | " + strategy.getStrategyName();
    }
}