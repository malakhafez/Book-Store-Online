package model;

import java.io.Serializable;

public class NovelBook extends Book implements Serializable {
    private static final long serialVersionUID = 1L;

    public NovelBook(String title, String author) {
        super(title, author, "Novel");
    }

    @Override
    public String read() {
        return super.read() + "\n📖 This is an exciting literary novel.";
    }
}