package model;

import java.io.Serializable;

public class ScienceBook extends Book implements Serializable {
    private static final long serialVersionUID = 1L;

    public ScienceBook(String title, String author) {
        super(title, author, "Science");
    }

    @Override
    public String read() {
        return super.read() + "\n🔬 This is a science book explaining natural phenomena.";
    }
}