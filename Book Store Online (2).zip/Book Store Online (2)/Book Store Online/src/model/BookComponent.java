package model;

public interface BookComponent {
    String getTitle();
    String getAuthor();
    String read();  // دي هتضيفها
}