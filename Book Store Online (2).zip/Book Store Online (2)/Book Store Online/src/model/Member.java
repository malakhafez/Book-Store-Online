package model;

import strategy.BorrowStrategy;
import java.io.Serializable;

public class Member extends User implements Serializable {
    private static final long serialVersionUID = 1L;

    // ✅ Reference to BorrowStrategy (حسب طلبك)
    private BorrowStrategy borrowStrategy;

    public Member(String fullName, String email, String password) {
        super(fullName, email, password, "Member");
        this.borrowStrategy = new strategy.WeeklyBorrow(); // Default Strategy
    }

    // Getters & Setters
    public BorrowStrategy getBorrowStrategy() {
        return borrowStrategy;
    }

    public void setBorrowStrategy(BorrowStrategy borrowStrategy) {
        this.borrowStrategy = borrowStrategy;
    }

    // اختيار استراتيجية جديدة
    public void chooseBorrowStrategy(BorrowStrategy strategy) {
        this.borrowStrategy = strategy;
        System.out.println("✅ تم تغيير طريقة الإعارة إلى: " + strategy.getStrategyName());
    }
}