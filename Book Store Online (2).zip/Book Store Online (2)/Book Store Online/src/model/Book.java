package model;

import state.BookState;
import state.AvailableState;
import java.io.Serializable;

public abstract class Book implements Serializable, BookComponent {
    private static final long serialVersionUID = 1L;
    private static int counter = 1;

    protected int bookId;
    protected String title;
    protected String author;
    protected BookState state;
    protected String category;

    public Book(String title, String author, String category) {
        this.bookId = counter++;
        this.title = title;
        this.author = author;
        this.category = category;
        this.state = new AvailableState();
    }

    // Getters
    public int getBookId() { return bookId; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getCategory() { return category; }
    public BookState getState() { return state; }

    public void setState(BookState state) { this.state = state; }
    public String borrow() { return state.borrow(this); }
    public String reserve() { return state.reserve(this); }
    public String returnBook() { return state.returnBook(this); }
    public String getStateName() {
        return state.getStateName();
    }

    // Setters
    public void setTitle(String title) { this.title = title; }
    public void setAuthor(String author) { this.author = author; }

    public static void setCounter(int value) {
        counter = value;
    }

    @Override
    public String read() {
        return "Reading: " + title + " (" + category + ")";
    }

    @Override
    public String toString() {
        return "[" + category + "] " + title + " - " + author;
    }
}