package model;
import java.io.Serializable;

public abstract class User implements Serializable {
    private static int counter = 1;
    private int userId;
    private String fullName;
    private String email;
    private String password;
    private String role;
    private static final long serialVersionUID = 1L;
    public User(String fullName, String email, String password, String role) {
        this.userId = counter++;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.role = role;
    }


    // Getters
    public int getUserId() { return userId; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getRole() { return role; }

    // Setters
    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setPassword(String password) { this.password = password; }
    public static void setCounter(int value) {
        counter = value;
    }
}