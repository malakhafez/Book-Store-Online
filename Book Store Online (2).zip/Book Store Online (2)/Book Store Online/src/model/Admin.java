package model;

import java.io.Serializable;

public class Admin extends User implements Serializable {
    private static final long serialVersionUID = 1L;

    public Admin(String fullName, String email, String password) {
        super(fullName, email, password, "Admin");
    }
}