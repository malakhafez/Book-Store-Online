package model;

import java.io.Serializable;

public class HistoryBook extends Book implements Serializable {
    private static final long serialVersionUID = 1L;

    public HistoryBook(String title, String author) {
        super(title, author, "History");
    }

    @Override
    public String read() {
        return super.read() + "\n📜 This is a history book narrating past events.";
    }
}