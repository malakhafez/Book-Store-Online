package model;

import java.io.Serializable;

public class Librarian extends User implements Serializable {
    private static final long serialVersionUID = 1L;

    public Librarian(String fullName, String email, String password) {
        super(fullName, email, password, "Librarian");
    }
}